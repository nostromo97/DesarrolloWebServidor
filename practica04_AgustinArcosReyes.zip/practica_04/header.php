<nav class="navbar navbar-expand-lg bg-warning">
  <div class="d-flex justify-content-start">
  <div class="container-fluid">
    <a class="navbar-brand" href="http://localhost/DesarrolloWebServidor/DesarrolloWebServidor/practica_04/">Ropita Linda: Tienda Online</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="http://localhost/DesarrolloWebServidor/DesarrolloWebServidor/practica_04/utilDB/desconectar.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="http://localhost/DesarrolloWebServidor/DesarrolloWebServidor/practica_04/public/prendas/index.php">Lista Prendas</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="http://localhost/DesarrolloWebServidor/DesarrolloWebServidor/practica_04/public/clientes/index.php">Clientes</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="http://localhost/DesarrolloWebServidor/DesarrolloWebServidor/practica_04/public/compras/index.php">Compras</a>
        </li>
      </ul>
    </div>
  </div>
</div>
</nav>